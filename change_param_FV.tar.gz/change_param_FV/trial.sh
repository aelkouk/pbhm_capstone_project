#!/bin/bash

#SBATCH --job-name=test
#SBATCH --ntasks=1
#SBATCH --time=0-00:20:00

# load the matlab module for running the 'change_param.m' function
module load matlab/2020a

# define paths
base_path=${HOME}/pbhmCourse_student/2_process_based_modelling
site_path=${base_path}/settings/plumber/Loobos
summa_settings=${site_path}/summa_zFileManager_Loobos.txt
SOILPARM_file=${site_path}/SOILPARM.TBL
sobol_file=${base_path}/SobolPAR_MatrixA.csv
summa_exe=${base_path}/summa.exe
log_file=${base_path}/log_summa.txt
param_to_mod=1

for row in {1..2}; do
        # Run script chnage SOILTBL using $row value in SobolPAR_Matrix.csv file
        # Script takes as input: $SOILPARM_file, $SobolMatrix, $row,
        # Change the name of the table
	 mv $SOILPARM_file ${site_path}/"SOILPARM_or.TBL"
	    # matlab code 1
         matlab -batch "change_param($row,$param_to_mod,'$sobol_file','$SOILPARM_file')"
        # matlab code 2
         #matlab -batch "change_param_all($row,'$sobol_file','$SOILPARM_file')"
        # Run summa with $row as output suffix
         summa_command="$summa_exe -m $summa_settings --suffix $row"

        # Run as [SUMMA call] > [log file path]
	$summa_command >> $log_file
done
